import type {Dir,Lang,Translation,VocabularyItem} from '../types'
import {LANGS} from '../types'
export const DIR:Record<Lang,Dir>={ar:'rtl',fr:'ltr',en:'ltr',mz:'ltr'}
export const norm=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f\u064B-\u065F\u0670]/g,'').toLowerCase().trim()
export const trOf=(it:VocabularyItem,l:Lang)=>it.translations.find(x=>x.language===l&&x.text)
export const texts=(it:VocabularyItem):Translation[]=>LANGS.map(l=>l===it.sourceLanguage?({...it.srcMeta,language:l,text:it.sourceText,source:'manual',verified:true} as Translation):trOf(it,l)).filter((x):x is Translation=>!!x)
export const missing=(it:VocabularyItem)=>LANGS.filter(l=>l!==it.sourceLanguage&&!trOf(it,l))
export const hay=(it:VocabularyItem)=>norm([it.sourceText,it.category,it.notes,...it.translations.flatMap(x=>[x.text,x.pronunciation,...x.alternatives])].join(' '))
