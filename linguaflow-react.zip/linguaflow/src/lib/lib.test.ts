import {describe,expect,it} from 'vitest'
import {hay,missing,norm} from './text'
import {translate,TranslateError} from './translate'
import {parseImport} from './importer'
import type {VocabularyItem} from '../types'
const m={pronunciation:'',alternatives:[],dir:'ltr' as const}
const item:VocabularyItem={id:'1',type:'word',sourceLanguage:'ar',sourceText:'مدرسة',srcMeta:{...m,dir:'rtl'},translations:[{language:'fr',text:'École',source:'manual',verified:true,...m}],category:'',difficulty:1,notes:'',examples:[],status:'new',createdAt:1,updatedAt:1}
const resp=(body:unknown,status=200)=>Promise.resolve(new Response(JSON.stringify(body),{status}))
describe('text',()=>{it('finds items by any translation, ignoring accents',()=>{expect(hay(item)).toContain(norm('ecole'))})
it('reports missing translations',()=>{expect(missing(item)).toEqual(['en','mz'])})})
describe('translate',()=>{
it('returns the translated text',async()=>{expect(await translate('مدرسة','ar','fr',()=>resp({responseStatus:200,responseData:{translatedText:'école'}}))).toBe('école')})
it('never translates Mozabite',async()=>{await expect(translate('x','ar','mz')).rejects.toMatchObject({code:'unsupported'})})
it('maps rate limiting',async()=>{await expect(translate('a','en','fr',()=>resp({},429))).rejects.toBeInstanceOf(TranslateError)})
it('maps network failure to offline',async()=>{await expect(translate('a','en','fr',()=>Promise.reject(new Error('x')))).rejects.toMatchObject({code:'offline'})})})
describe('import',()=>{it('skips duplicates and invalid rows',()=>{const r=parseImport(JSON.stringify({items:[item,{foo:1},{...item,id:'2',sourceText:'كتاب'}]}),[item])!;expect(r.items).toHaveLength(1);expect(r.skipped).toBe(2)})
it('rejects bad JSON',()=>{expect(parseImport('{',[])).toBeNull()})})
