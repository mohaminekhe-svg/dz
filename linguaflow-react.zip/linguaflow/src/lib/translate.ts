import type {Lang} from '../types'
export type TErr='offline'|'unsupported'|'limit'|'failed'|'long'
export class TranslateError extends Error{constructor(public code:TErr){super(code)}}
/** Real translation via the MyMemory public API (no key, ~500 chars per request, daily quota).
 *  Mozabite is never machine-translated. For production or heavy use, route this through your own serverless proxy. */
export async function translate(text:string,from:Lang,to:Lang,f:typeof fetch=(...a)=>fetch(...a)):Promise<string>{
if(from==='mz'||to==='mz'||from===to)throw new TranslateError('unsupported')
if(text.length>500)throw new TranslateError('long')
if(typeof navigator!=='undefined'&&navigator.onLine===false)throw new TranslateError('offline')
let r:Response
try{r=await f(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${from}|${to}`)}catch{throw new TranslateError('offline')}
if(r.status===429)throw new TranslateError('limit')
if(!r.ok)throw new TranslateError('failed')
const j=await r.json().catch(()=>null)
if(Number(j?.responseStatus)===429)throw new TranslateError('limit')
const out=j?.responseData?.translatedText
if(Number(j?.responseStatus)!==200||typeof out!=='string'||!out.trim())throw new TranslateError('failed')
return out.trim()}
