import {LANGS,STATUSES,TYPES,type Dir,type Lang,type Meta,type VocabularyItem} from '../types'
import {norm} from './text'
const dir=(d:unknown):Dir=>d==='rtl'?'rtl':'ltr'
const meta=(x:any):Meta=>({pronunciation:String(x?.pronunciation||''),alternatives:Array.isArray(x?.alternatives)?x.alternatives.map(String):[],dir:dir(x?.dir)})
/** Import is untrusted input: every field is validated, duplicates are skipped. */
export function parseImport(raw:string,existing:VocabularyItem[]):{items:VocabularyItem[];skipped:number}|null{
let j:any;try{j=JSON.parse(raw)}catch{return null}
const arr=Array.isArray(j)?j:Array.isArray(j?.items)?j.items:null;if(!arr)return null
const out:VocabularyItem[]=[];let skipped=0;const all=()=>[...existing,...out]
for(const x of arr){
if(!x||typeof x.sourceText!=='string'||!x.sourceText.trim()||!LANGS.includes(x.sourceLanguage)||!Array.isArray(x.translations)){skipped++;continue}
if(all().some(i=>i.id===x.id||(i.sourceLanguage===x.sourceLanguage&&norm(i.sourceText)===norm(x.sourceText)))){skipped++;continue}
out.push({id:typeof x.id==='string'?x.id:crypto.randomUUID(),type:TYPES.includes(x.type)?x.type:'word',sourceLanguage:x.sourceLanguage as Lang,sourceText:x.sourceText.trim().slice(0,1000),srcMeta:meta(x.srcMeta),
translations:x.translations.filter((y:any)=>y&&LANGS.includes(y.language)&&typeof y.text==='string'&&y.text.trim()).map((y:any)=>({language:y.language,text:y.text.trim().slice(0,1000),source:'imported' as const,verified:!!y.verified,...meta(y)})),
category:String(x.category||''),difficulty:[1,2,3].includes(x.difficulty)?x.difficulty:1,notes:String(x.notes||''),examples:Array.isArray(x.examples)?x.examples.map(String):[],status:STATUSES.includes(x.status)?x.status:'new',createdAt:+x.createdAt||Date.now(),updatedAt:Date.now()})}
return{items:out,skipped}}
