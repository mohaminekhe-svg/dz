import Dexie,{type Table} from 'dexie'
import type {Settings,VocabularyItem} from './types'
class LinguaDB extends Dexie{items!:Table<VocabularyItem,string>;settings!:Table<{k:string;v:Settings},string>
constructor(){super('linguaflow');this.version(1).stores({items:'id,sourceLanguage,status,createdAt',settings:'k'})}}
export const db=new LinguaDB()
