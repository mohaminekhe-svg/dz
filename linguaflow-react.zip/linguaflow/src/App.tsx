import {useEffect,useState} from 'react'
import {db} from './db'
import {mk} from './i18n'
import {ItemForm} from './ItemForm'
import {Dashboard,Icon,SettingsView,Vocab} from './views'
import type {Settings,VocabularyItem} from './types'
type View='dash'|'vocab'|'set'
export default function App(){
const [items,setItems]=useState<VocabularyItem[]>([]),[set,setSet]=useState<Settings>({ui:'ar',theme:'auto'}),[view,setView]=useState<View>('dash'),[form,setForm]=useState<VocabularyItem|'new'|null>(null),[ok,setOk]=useState(true)
const {t}=mk(set.ui)
useEffect(()=>{(async()=>{try{const s=await db.settings.get('s');if(s)setSet(s.v);setItems(await db.items.toArray())}catch{setOk(false)}})()},[])
useEffect(()=>{const r=document.documentElement;r.lang=set.ui;r.dir=set.ui==='ar'?'rtl':'ltr';if(set.theme==='auto')r.removeAttribute('data-theme');else r.dataset.theme=set.theme},[set])
const persist=async(p:Promise<unknown>)=>{try{await p}catch{setOk(false)}}
const save=(it:VocabularyItem)=>{setItems(s=>s.some(i=>i.id===it.id)?s.map(i=>i.id===it.id?it:i):[it,...s]);persist(db.items.put(it));setForm(null)}
const add=()=>setForm('new')
const nav:[View|'quiz'|'stats',boolean][]=[['dash',false],['vocab',false],['quiz',true],['stats',true],['set',false]]
return<div id="app"><nav aria-label="LinguaFlow"><div className="logo">LinguaFlow</div>
{nav.map(([k,off])=><button key={k} className={`nb ${view===k?'on':''}`} disabled={off} onClick={()=>!off&&setView(k as View)}><Icon n={k}/><span>{t(k)}</span>{off&&<small>{t('soon')}</small>}</button>)}</nav>
<main>{!ok&&<div className="banner">{t('nodb')}</div>}
{view==='dash'&&<Dashboard items={items} ui={set.ui} onAdd={add}/>}
{view==='vocab'&&<Vocab items={items} ui={set.ui} onAdd={add} onEdit={setForm} onDelete={id=>{setItems(s=>s.filter(i=>i.id!==id));persist(db.items.delete(id))}}/>}
{view==='set'&&<SettingsView items={items} set={set} onSet={s=>{setSet(s);persist(db.settings.put({k:'s',v:s}))}} onImport={n=>{setItems(s=>[...n,...s]);persist(db.items.bulkPut(n))}}/>}</main>
{view==='vocab'&&items.length>0&&<button className="btn fab" onClick={add}><Icon n="plus"/> {t('add')}</button>}
{form&&<ItemForm item={form==='new'?null:form} items={items} ui={set.ui} onSave={save} onClose={()=>setForm(null)}/>}</div>}
