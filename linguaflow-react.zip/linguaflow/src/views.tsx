import {useState} from 'react'
import {LANGS,STATUSES,TYPES,type Settings,type VocabularyItem} from './types'
import {NM,mk,type Ui} from './i18n'
import {DIR,hay,missing,norm,texts} from './lib/text'
import {parseImport} from './lib/importer'
const ico:Record<string,string>={dash:'<path d="M3 11l9-8 9 8v10H15v-7H9v7H3z"/>',vocab:'<path d="M4 4h6a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4zM20 4h-6a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h7z"/>',quiz:'<path d="M12 3l10 5-10 5L2 8zM6 11v5c3 3 9 3 12 0v-5"/>',stats:'<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',set:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',plus:'<path d="M12 5v14M5 12h14"/>'}
export const Icon=({n}:{n:string})=><svg viewBox="0 0 24 24" aria-hidden="true" dangerouslySetInnerHTML={{__html:ico[n]}}/>
export function Dashboard({items,ui,onAdd}:{items:VocabularyItem[];ui:Ui;onAdd:()=>void}){
const {t}=mk(ui),n=items.length,w=items.filter(i=>i.type==='word').length,m=items.filter(i=>i.status==='mastered').length,rv=items.filter(i=>i.status==='review').length,day=new Date().toDateString(),td=items.filter(i=>new Date(i.createdAt).toDateString()===day).length
if(!n)return<><h1>LinguaFlow</h1><div className="card empty"><h2>{t('et')}</h2><p className="hint">{t('ed')}</p><button className="btn" onClick={onAdd}><Icon n="plus"/> {t('add')}</button><p className="hint">{t('loc')}</p></div></>
return<><h1>LinguaFlow</h1><p className="msg">{rv?t('m1'):td?t('m2'):t('m0')}</p>
<div className="grid">{([[w,'words'],[n-w,'phr'],[m,'done'],[rv,'rev'],[td,'today']] as [number,string][]).map(([v,k])=><div className="card st" key={k}><b>{v}</b><span>{t(k)}</span></div>)}</div>
<h2>{t('lanes')}</h2><div className="card">{LANGS.map(l=>{const c=items.filter(i=>texts(i).some(x=>x.language===l)).length;return<div className="lane" key={l}><span lang={l} dir={DIR[l]}>{NM[ui][l]}</span><div className="bar"><i style={{width:`${Math.round(c/n*100)}%`,background:`var(--c-${l})`}}/></div><b>{c}</b></div>})}</div>
<p className="hint">{t('pend')}</p></>}
export function Vocab({items,ui,onAdd,onEdit,onDelete}:{items:VocabularyItem[];ui:Ui;onAdd:()=>void;onEdit:(i:VocabularyItem)=>void;onDelete:(id:string)=>void}){
const {t,tt}=mk(ui),[q,setQ]=useState(''),[st,setSt]=useState(''),[inc,setInc]=useState(false),[conf,setConf]=useState<string|null>(null),nq=norm(q)
const L=items.filter(i=>(!nq||hay(i).includes(nq))&&(!st||i.status===st)&&(!inc||missing(i).length)).sort((a,b)=>b.createdAt-a.createdAt)
return<><h1>{t('vocab')}</h1>
<div className="bar2"><input type="search" dir="auto" placeholder={t('q')} aria-label={t('q')} value={q} onChange={e=>setQ(e.target.value)}/>
<select value={st} onChange={e=>setSt(e.target.value)}><option value="">{t('all')}</option>{STATUSES.map((k,i)=><option key={k} value={k}>{tt('s',i)}</option>)}</select>
<label className="chip" style={{display:'flex',alignItems:'center',gap:6,minHeight:44}}><input type="checkbox" checked={inc} onChange={e=>setInc(e.target.checked)} style={{width:'auto',minHeight:0}}/> {t('inc')}</label></div>
{!items.length?<div className="card empty"><h2>{t('et')}</h2><p className="hint">{t('ed')}</p><button className="btn" onClick={onAdd}><Icon n="plus"/> {t('add')}</button></div>
:L.length?L.map(it=>{const ms=missing(it),tx=texts(it);return<div className="card it" key={it.id}>
{tx.map(x=><div className="tr" key={x.language}><span className="ln" style={{color:`var(--c-${x.language})`}}>{NM[ui][x.language]}</span><div><div className="tx" lang={x.language} dir={x.dir}>{x.text}</div>
{x.pronunciation&&<div className="pn" dir="ltr">/{x.pronunciation}/</div>}{x.alternatives.length>0&&<div className="pn" dir={x.dir}>{x.alternatives.join(' · ')}</div>}</div></div>)}
{it.notes&&<p className="hint" dir="auto">{it.notes}</p>}
<div className="row"><span className="chip">{tt('t',TYPES.indexOf(it.type))}</span><span className="chip">{tt('s',STATUSES.indexOf(it.status))}</span>{it.category&&<span className="chip" dir="auto">{it.category}</span>}
{tx.some(x=>x.source==='machine'&&!x.verified)&&<span className="chip w">{t('mach')}</span>}
{ms.length>0&&<span className="chip w">{t('miss')} {ms.map(l=>NM[ui][l]).join('، ')}</span>}
<span style={{marginInlineStart:'auto',display:'flex',gap:8}}>{conf===it.id?<><button className="btn d" onClick={()=>{onDelete(it.id);setConf(null)}}>{t('sure')}</button><button className="btn g" onClick={()=>setConf(null)}>{t('cancel')}</button></>:<><button className="btn g" onClick={()=>onEdit(it)}>{t('edit')}</button><button className="btn g" onClick={()=>setConf(it.id)}>{t('del')}</button></>}</span></div></div>})
:<p className="hint">{t('none')}</p>}</>}
export function SettingsView({items,set,onSet,onImport}:{items:VocabularyItem[];set:Settings;onSet:(s:Settings)=>void;onImport:(i:VocabularyItem[])=>void}){
const {t,tt}=mk(set.ui),[raw,setRaw]=useState(''),[msg,setMsg]=useState('')
function imp(){const r=parseImport(raw,items);if(!r)return setMsg(t('bad'));onImport(r.items);setMsg(t('ok').replace('%a',String(r.items.length)).replace('%b',String(r.skipped)))}
return<><h1>{t('set')}</h1><div className="card f" style={{display:'grid',gap:14}}>
<div><label>{t('ui')}</label><select value={set.ui} onChange={e=>onSet({...set,ui:e.target.value as Ui})}><option value="ar">العربية</option><option value="fr">Français</option><option value="en">English</option></select></div>
<div><label>{t('th')}</label><select value={set.theme} onChange={e=>onSet({...set,theme:e.target.value as Settings['theme']})}>{['auto','light','dark'].map((k,i)=><option key={k} value={k}>{tt('tt',i)}</option>)}</select></div><p className="hint">{t('loc')}</p></div>
<h2>{t('bk')}</h2><div className="card f" style={{display:'grid',gap:10}}>
<label>{t('ex2')}</label><textarea rows={4} readOnly dir="ltr" value={JSON.stringify({app:'linguaflow',version:1,items})}/>
<button className="btn g" style={{justifySelf:'start'}} onClick={()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({app:'linguaflow',version:1,items},null,1)],{type:'application/json'}));a.download='linguaflow-backup.json';a.click()}}>JSON ⬇</button>
<label>{t('im')}</label><textarea rows={4} dir="ltr" value={raw} onChange={e=>setRaw(e.target.value)}/>
<div><button className="btn" onClick={imp}>{t('ib')}</button></div><p className="hint" role="status">{msg}</p></div></>}
