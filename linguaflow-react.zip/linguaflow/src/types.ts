export type Lang='ar'|'fr'|'en'|'mz'
export const LANGS:Lang[]=['ar','fr','en','mz'] // 'mz' is an internal id, not necessarily an ISO code
export type Status='new'|'learning'|'review'|'mastered'
export const STATUSES:Status[]=['new','learning','review','mastered']
export type ItemType='word'|'sentence'|'expression'
export const TYPES:ItemType[]=['word','sentence','expression']
export type Dir='ltr'|'rtl'
export interface Meta{pronunciation:string;alternatives:string[];dir:Dir}
export interface Translation extends Meta{language:Lang;text:string;source:'manual'|'machine'|'imported';verified:boolean}
export interface VocabularyItem{id:string;type:ItemType;sourceLanguage:Lang;sourceText:string;srcMeta:Meta;translations:Translation[];category:string;difficulty:1|2|3;notes:string;examples:string[];status:Status;createdAt:number;updatedAt:number}
export interface Settings{ui:'ar'|'fr'|'en';theme:'auto'|'light'|'dark'}
