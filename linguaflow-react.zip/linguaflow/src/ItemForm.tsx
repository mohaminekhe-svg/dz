import {useEffect,useRef,useState} from 'react'
import {LANGS,STATUSES,TYPES,type Dir,type Lang,type VocabularyItem} from './types'
import {NM,mk,type Ui} from './i18n'
import {DIR,norm,trOf} from './lib/text'
import {translate,TranslateError} from './lib/translate'
type F={text:string;pron:string;alt:string;dir:Dir;machine:boolean}
const MT:Lang[]=['fr','en'] // languages that get a translate button
export function ItemForm({item,items,ui,onSave,onClose}:{item:VocabularyItem|null;items:VocabularyItem[];ui:Ui;onSave:(i:VocabularyItem)=>void;onClose:()=>void}){
const {t,tt}=mk(ui),ref=useRef<HTMLDialogElement>(null)
const [type,setType]=useState(item?.type??'word'),[sl,setSl]=useState<Lang>(item?.sourceLanguage??ui)
const [fl,setFl]=useState<Record<Lang,F>>(()=>Object.fromEntries(LANGS.map(l=>{const x=l===item?.sourceLanguage?{...item.srcMeta,text:item.sourceText,source:'manual'}:item&&trOf(item,l);
return[l,{text:x?.text??'',pron:x?.pronunciation??'',alt:(x?.alternatives??[]).join(', '),dir:x?.dir??DIR[l],machine:x?.source==='machine'&&!x.verified}]})) as Record<Lang,F>)
const [cat,setCat]=useState(item?.category??''),[diff,setDiff]=useState(item?.difficulty??1),[st,setSt]=useState(item?.status??'new'),[ex,setEx]=useState(item?.examples[0]??''),[notes,setNotes]=useState(item?.notes??'')
const [err,setErr]=useState(''),[busy,setBusy]=useState<Lang|null>(null)
useEffect(()=>{ref.current?.showModal()},[])
const up=(l:Lang,p:Partial<F>)=>setFl(s=>({...s,[l]:{...s[l],...p}}))
async function tr(l:Lang){const src=fl[sl].text.trim();if(!src)return setErr(t('req'));setErr('');setBusy(l)
try{up(l,{text:await translate(src,sl,l),machine:true,dir:DIR[l]})}
catch(e){setErr(t(({offline:'eoff',unsupported:'euns',limit:'elim',long:'elong',failed:'efail'} as Record<string,string>)[e instanceof TranslateError?e.code:'failed']))}finally{setBusy(null)}}
function save(){const src=fl[sl].text.trim();if(!src)return setErr(t('req'))
if(items.some(i=>i.id!==item?.id&&i.sourceLanguage===sl&&norm(i.sourceText)===norm(src)))return setErr(t('dup'))
const m=(l:Lang)=>({pronunciation:fl[l].pron.trim(),alternatives:fl[l].alt.split(',').map(s=>s.trim()).filter(Boolean),dir:fl[l].dir})
const now=Date.now()
onSave({id:item?.id??crypto.randomUUID(),type,sourceLanguage:sl,sourceText:src,srcMeta:m(sl),
translations:LANGS.filter(l=>l!==sl&&fl[l].text.trim()).map(l=>({language:l,text:fl[l].text.trim(),source:fl[l].machine?'machine' as const:'manual' as const,verified:!fl[l].machine,...m(l)})),
category:cat.trim(),difficulty:diff,notes:notes.trim(),examples:ex.trim()?[ex.trim()]:[],status:st,createdAt:item?.createdAt??now,updatedAt:now})}
return<dialog ref={ref} onClose={onClose}><div className="dl f">
<h2 style={{margin:0}}>{t('add')}</h2>
<div className="two"><div><label>{t('type')}</label><select value={type} onChange={e=>setType(e.target.value as typeof type)}>{TYPES.map((k,i)=><option key={k} value={k}>{tt('t',i)}</option>)}</select></div>
<div><label>{t('src')}</label><select value={sl} onChange={e=>setSl(e.target.value as Lang)}>{LANGS.map(l=><option key={l} value={l}>{NM[ui][l]}</option>)}</select></div></div>
{LANGS.map(l=><div className="lb" key={l}>
<label style={{color:`var(--c-${l})`,fontWeight:500}}>{NM[ui][l]} {l!==sl&&<span className="hint">({t('opt')})</span>}</label>
<div style={{display:'flex',gap:8}}>
<input className="tx" lang={l} dir={fl[l].dir} value={fl[l].text} onChange={e=>up(l,{text:e.target.value,machine:false})} style={{flex:1,border:'1px solid var(--bd)',borderRadius:10,padding:10,minHeight:44,background:'var(--sf)'}}/>
{MT.includes(l)&&l!==sl&&<button type="button" className="btn g" disabled={busy!==null} onClick={()=>tr(l)}>{busy===l?t('trl'):t('tr')}</button>}</div>
{fl[l].machine&&<p className="hint">{t('tm')}</p>}
{l==='mz'&&<p className="hint">{t('mzh')}</p>}
<details><summary>{t('pron')} / {t('alt')}</summary><div className="two" style={{marginTop:8}}>
<input dir="ltr" placeholder={t('pron')} value={fl[l].pron} onChange={e=>up(l,{pron:e.target.value})}/>
<input lang={l} dir={fl[l].dir} placeholder={t('alt')} value={fl[l].alt} onChange={e=>up(l,{alt:e.target.value})}/>
{l==='mz'&&<select aria-label={t('dirl')} value={fl[l].dir} onChange={e=>up(l,{dir:e.target.value as Dir})}><option value="ltr">LTR</option><option value="rtl">RTL</option></select>}</div></details></div>)}
<div className="two"><div><label>{t('cat')}</label><input dir="auto" value={cat} onChange={e=>setCat(e.target.value)}/></div>
<div><label>{t('diff')}</label><select value={diff} onChange={e=>setDiff(+e.target.value as 1|2|3)}>{[1,2,3].map(n=><option key={n} value={n}>{tt('d',n-1)}</option>)}</select></div></div>
<div className="two"><div><label>{t('stt')}</label><select value={st} onChange={e=>setSt(e.target.value as typeof st)}>{STATUSES.map((k,i)=><option key={k} value={k}>{tt('s',i)}</option>)}</select></div>
<div><label>{t('ex')}</label><input dir="auto" value={ex} onChange={e=>setEx(e.target.value)}/></div></div>
<div><label>{t('notes')}</label><textarea dir="auto" rows={2} value={notes} onChange={e=>setNotes(e.target.value)}/></div>
<div className="err" role="alert">{err}</div>
<div style={{display:'flex',gap:10,justifyContent:'flex-end'}}><button type="button" className="btn g" onClick={()=>ref.current?.close()}>{t('cancel')}</button><button type="button" className="btn" onClick={save}>{t('save')}</button></div>
</div></dialog>}
