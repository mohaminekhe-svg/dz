export const NM:Record<string,Record<string,string>>={ar:{ar:'العربية',fr:'الفرنسية',en:'الإنجليزية',mz:'المزابية Tumẓabt'},fr:{ar:'Arabe',fr:'Français',en:'Anglais',mz:'Mozabite Tumẓabt'},en:{ar:'Arabic',fr:'French',en:'English',mz:'Mozabite Tumẓabt'}};
export const D:Record<string,readonly any[]>={dash:['الرئيسية','Accueil','Home'],vocab:['مفرداتي','Mon vocabulaire','My vocabulary'],quiz:['اختبر نفسك','Quiz','Quiz'],stats:['إحصائياتي','Statistiques','Stats'],set:['الإعدادات','Réglages','Settings'],soon:['قريبًا','Bientôt','Soon'],
add:['إضافة كلمة أو جملة','Ajouter un mot ou une phrase','Add a word or phrase'],q:['ابحث في النصوص والترجمات','Rechercher dans les textes et traductions','Search texts and translations'],all:['الكل','Tous','All'],inc:['ترجمات ناقصة','Traductions manquantes','Missing translations'],
words:['كلمات','Mots','Words'],phr:['جمل وتعابير','Phrases et expressions','Phrases & expressions'],done:['متقنة','Maîtrisés','Mastered'],rev:['تحتاج مراجعة','À revoir','Needs review'],today:['أُضيفت اليوم','Ajoutés aujourd’hui','Added today'],
lanes:['حضور كل لغة في مفرداتك','Présence de chaque langue','Each language in your vocabulary'],et:['ابدأ بأول كلمة','Commencez par un premier mot','Start with your first word'],
ed:['احفظ كلمة بلغة واحدة، وأضف باقي الترجمات متى شئت.','Enregistrez un mot dans une langue, ajoutez les autres traductions plus tard.','Save a word in one language and add the other translations whenever you like.'],
m0:['خطوة صغيرة اليوم، وطلاقة أكبر غدًا.','Un petit pas aujourd’hui, plus d’aisance demain.','A small step today, more fluency tomorrow.'],m1:['راجع ما تعلمته، فالتكرار يصنع الفرق.','Révisez ce que vous savez : la répétition fait la différence.','Review what you know: repetition makes the difference.'],m2:['كل كلمة تتعلمها اليوم تقرّبك من هدفك.','Chaque mot appris vous rapproche de votre but.','Every word you learn brings you closer to your goal.'],
save:['حفظ','Enregistrer','Save'],cancel:['إلغاء','Annuler','Cancel'],del:['حذف','Supprimer','Delete'],sure:['تأكيد الحذف النهائي','Confirmer la suppression','Confirm delete'],edit:['تعديل','Modifier','Edit'],
type:['النوع','Type','Type'],t:[['كلمة','جملة','تعبير'],['Mot','Phrase','Expression'],['Word','Sentence','Expression']],src:['اللغة الأصلية','Langue d’origine','Source language'],
pron:['النطق / الكتابة الصوتية','Prononciation','Pronunciation'],alt:['كتابات بديلة (افصل بفاصلة)','Graphies alternatives (virgule)','Alternative spellings (comma)'],dirl:['اتجاه الكتابة','Sens d’écriture','Writing direction'],
notes:['ملاحظات','Notes','Notes'],ex:['مثال على الاستخدام','Exemple d’usage','Usage example'],cat:['التصنيف','Catégorie','Category'],diff:['الصعوبة','Difficulté','Difficulty'],
d:[['سهل','متوسط','صعب'],['Facile','Moyen','Difficile'],['Easy','Medium','Hard']],stt:['الحالة','Statut','Status'],
s:[['جديد','قيد التعلم','يحتاج مراجعة','متقن'],['Nouveau','En cours','À revoir','Maîtrisé'],['New','Learning','Needs review','Mastered']],
mzh:['اكتبها بنفسك؛ لا يقترح التطبيق أي ترجمة مزابية.','Saisissez-la vous-même ; l’app ne suggère aucune traduction mozabite.','Enter it yourself; the app never suggests Mozabite translations.'],
opt:['اختياري','facultatif','optional'],dup:['هذا العنصر موجود مسبقًا.','Cet élément existe déjà.','This item already exists.'],req:['اكتب النص في حقل اللغة الأصلية.','Saisissez le texte dans la langue d’origine.','Fill in the text of the source language.'],
none:['لا نتائج مطابقة.','Aucun résultat.','No matching results.'],miss:['ناقص:','Manque :','Missing:'],ui:['لغة الواجهة','Langue de l’interface','Interface language'],th:['المظهر','Thème','Theme'],tt:[['تلقائي','فاتح','داكن'],['Auto','Clair','Sombre'],['Auto','Light','Dark']],
bk:['النسخ الاحتياطي والاستيراد','Sauvegarde et import','Backup and import'],ex2:['تصدير (JSON): انسخ النص واحفظه في ملف','Export (JSON) : copiez et enregistrez dans un fichier','Export (JSON): copy and save to a file'],
im:['استيراد: الصق JSON هنا','Import : collez le JSON ici','Import: paste JSON here'],ib:['استيراد','Importer','Import'],ok:['تم استيراد %a وتجاهل %b مكررًا أو غير صالح.','%a importés, %b ignorés (doublons ou invalides).','Imported %a, skipped %b duplicate or invalid.'],
bad:['JSON غير صالح.','JSON invalide.','Invalid JSON.'],loc:['بياناتك محفوظة محليًا على هذا الجهاز فقط.','Vos données restent sur cet appareil.','Your data stays on this device only.'],
nodb:['تعذّر التخزين الدائم في هذا المتصفح؛ ستُفقد البيانات عند الإغلاق.','Stockage persistant indisponible : les données seront perdues à la fermeture.','Persistent storage unavailable: data is lost on close.'],
pend:['الاختبارات والإحصائيات المفصلة تأتي مع المرحلة الثالثة؛ لا تُعرض هنا أرقام غير حقيقية.','Quiz et statistiques détaillées arrivent en phase 3 ; aucun chiffre fictif ici.','Quizzes and detailed stats arrive in phase 3; no made-up numbers shown here.']};
Object.assign(D,{
tr:['ترجمة','Traduire','Translate'],trl:['جارٍ الترجمة…','Traduction…','Translating…'],
tm:['ترجمة آلية — راجعها قبل الحفظ','Traduction automatique — à vérifier','Machine translation — review before saving'],mach:['آلية','Auto','Auto'],
eoff:['لا يوجد اتصال بالإنترنت.','Pas de connexion Internet.','No Internet connection.'],
euns:['الترجمة الآلية غير متاحة لهذه اللغة (المزابية بالإدخال اليدوي).','Traduction automatique indisponible pour cette langue (mozabite : saisie manuelle).','Machine translation isn’t available for this language (Mozabite is manual).'],
elim:['تجاوزت حد الاستخدام، جرّب لاحقًا.','Limite d’utilisation atteinte, réessayez plus tard.','Usage limit reached, try again later.'],
efail:['تعذّرت الترجمة، حاول مرة أخرى.','Échec de la traduction, réessayez.','Translation failed, try again.'],
elong:['النص أطول من 500 حرف.','Texte de plus de 500 caractères.','Text longer than 500 characters.']})
const IX={ar:0,fr:1,en:2} as const
export type Ui=keyof typeof IX
export const mk=(ui:Ui)=>({t:(k:string)=>D[k][IX[ui]] as string,tt:(k:string,i:number)=>D[k][IX[ui]][i] as string})
